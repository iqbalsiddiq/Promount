-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 27, 2016 at 02:03 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_promount`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) collate latin1_general_ci NOT NULL,
  `detail` text collate latin1_general_ci NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `image` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`, `detail`, `timestamp`, `image`) VALUES
(1, 'Food & Drink', '', '0000-00-00 00:00:00', 'food-and-drink-header.jpg'),
(2, 'Thinks To Do', '', '0000-00-00 00:00:00', ''),
(3, 'aa', '', '2016-10-16 10:29:55', 'food-and-drink-header.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) collate latin1_general_ci NOT NULL,
  `detail` text collate latin1_general_ci NOT NULL,
  `description` text collate latin1_general_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `image` text collate latin1_general_ci NOT NULL,
  `thumb` text collate latin1_general_ci NOT NULL,
  `url` text collate latin1_general_ci NOT NULL,
  `exclusive` varchar(11) collate latin1_general_ci NOT NULL,
  `featured` varchar(1) collate latin1_general_ci NOT NULL,
  `newdeals` varchar(1) collate latin1_general_ci NOT NULL,
  `topdeals` varchar(1) collate latin1_general_ci NOT NULL,
  `mostwanted` varchar(1) collate latin1_general_ci NOT NULL,
  `toppick` varchar(1) collate latin1_general_ci NOT NULL,
  `sale` varchar(1) collate latin1_general_ci NOT NULL,
  `new` varchar(1) collate latin1_general_ci NOT NULL,
  `location` varchar(50) collate latin1_general_ci NOT NULL,
  `IdMerchant` int(11) NOT NULL,
  `idCategory` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `title`, `detail`, `description`, `price`, `discount`, `image`, `thumb`, `url`, `exclusive`, `featured`, `newdeals`, `topdeals`, `mostwanted`, `toppick`, `sale`, `new`, `location`, `IdMerchant`, `idCategory`, `timestamp`) VALUES
(1, 'satu', 'satu', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet porttitor eros. Praesent quis diam placerat, accumsan velit interdum, accumsan orci. Nunc libero sem, elementum in semper in, sollicitudin vitae dolor. Etiam sed tempus nisl. Integer vel diam nulla. Suspendisse et aliquam est. Nulla molestie ante et tortor sollicitudin, at elementum odio lobortis. Pellentesque neque enim, feugiat in elit sed, pharetra tempus metus. Pellentesque non lorem nunc. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>\r\n\r\n                    <p>Sed consequat orci vel rutrum blandit. Nam non leo vel risus cursus porta quis non nulla. Vestibulum vitae pellentesque nunc. In hac habitasse platea dictumst. Cras egestas, turpis a malesuada mollis, magna tortor scelerisque urna, in pellentesque diam tellus sit amet velit. Donec vel rhoncus nisi, eget placerat elit. Phasellus dignissim nisl vel lectus vehicula, eget vehicula nisl egestas. Duis pretium sed risus dapibus egestas. Nam lectus felis, sodales sit amet turpis se.', 11, 1, 's1.jpg', 'img/thumb-003.jpg', '#', '1', '1', '1', '1', '1', '1', '1', '', 'dsada', 0, 1, '2016-11-13 10:48:02'),
(2, 'img/004.jpg', 'img/004.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet porttitor eros. Praesent quis diam placerat, accumsan velit interdum, accumsan orci. Nunc libero sem, elementum in semper in, sollicitudin vitae dolor. Etiam sed tempus nisl. Integer vel diam nulla. Suspendisse et aliquam est. Nulla molestie ante et tortor sollicitudin, at elementum odio lobortis. Pellentesque neque enim, feugiat in elit sed, pharetra tempus metus. Pellentesque non lorem nunc. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>\r\n\r\n                    <p>Sed consequat orci vel rutrum blandit. Nam non leo vel risus cursus porta quis non nulla. Vestibulum vitae pellentesque nunc. In hac habitasse platea dictumst. Cras egestas, turpis a malesuada mollis, magna tortor scelerisque urna, in pellentesque diam tellus sit amet velit. Donec vel rhoncus nisi, eget placerat elit. Phasellus dignissim nisl vel lectus vehicula, eget vehicula nisl egestas. Duis pretium sed risus dapibus egestas. Nam lectus felis, sodales sit amet turpis se.', 0, 0, 's2.jpg', 'img/thumb-004.jpg', '', '1', '1', '1', '1', '1', '1', '', '1', '', 0, 2, '2016-11-12 16:34:20'),
(3, 'img/005.jpg', '', '', 0, 0, 's3.jpg', 'img/thumb-005.jpg', '', '0', '1', '1', '1', '1', '1', '', '', '', 0, 2, '2016-10-16 11:59:08'),
(4, 'img/006.jpg', 'detai  ', '', 0, 0, 's4.jpg', 'img/thumb-006.jpg', '', '0', '1', '1', '1', '1', '1', '1', '', '', 0, 2, '2016-10-29 19:13:39'),
(5, 'dsadada', 'img/006.jpg	', '', 0, 0, 's2.jpg', 'img/thumb-007.jpg', '', '', '0', '', '1', '', '1', '', '', '', 0, 2, '2016-11-12 19:38:48'),
(6, 's2.jpg', 's2.jpg', '', 111, 10, 's2.jpg', 's2.jpg', 's2.jpg', '1', '1', '1', '1', '1', '1', '1', '1', 'dadas', 1, 1, '2016-10-19 23:39:07');

-- --------------------------------------------------------

--
-- Table structure for table `merchant`
--

CREATE TABLE IF NOT EXISTS `merchant` (
  `id` int(11) NOT NULL,
  `title` varchar(50) collate latin1_general_ci NOT NULL,
  `detail` text collate latin1_general_ci NOT NULL,
  `note` text collate latin1_general_ci NOT NULL,
  `image` text collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `merchant`
--

INSERT INTO `merchant` (`id`, `title`, `detail`, `note`, `image`) VALUES
(0, 'tes mercant 1', 'tes mercant 1', 'tes mercant 1', 'merchant1.png'),
(0, 'tes mercant 2', 'tes mercant 2', 'tes mercant 2', 'merchant2.png');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) collate utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2013_11_05_155858_create_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE IF NOT EXISTS `review` (
  `id` int(11) NOT NULL,
  `name` varchar(50) collate latin1_general_ci NOT NULL,
  `email` varchar(50) collate latin1_general_ci NOT NULL,
  `rating` int(50) NOT NULL,
  `review` text collate latin1_general_ci NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `iditem` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `review`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(32) collate utf8_unicode_ci NOT NULL,
  `email` varchar(320) collate utf8_unicode_ci NOT NULL,
  `password` varchar(64) collate utf8_unicode_ci NOT NULL,
  `role` varchar(10) collate utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `remember_token` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `updated_at`, `remember_token`) VALUES
(1, 'qqqq', '123qwe@gmail.com', '$2y$10$ko1QDvcP72dqUdmqfoWBc.R2mLm8jCyUdtbAa7SOFHQDsJe3wKxaG', '', '2016-09-30 01:58:24', '2016-09-30 09:33:08', 'RydyFILJXp2M8KDLvc4QETj9lBAjhAqhvwBqq0ixDULhM2503brJtmMs4sYo'),
(2, 'nanda', 'dsds@gmail.com', '1', '', '2016-11-26 09:56:19', '2016-11-26 09:56:19', ''),
(3, 'nanda', 'dsds222@gmail.com', '2', '', '2016-11-26 09:57:06', '2016-11-26 09:57:06', ''),
(4, 'defauluser', 'dsds@gmail.com', 'd', '', '2016-11-26 10:00:20', '2016-11-26 10:00:20', ''),
(5, 'defauluser', 'dsds@gmail.com', '33', '', '2016-11-26 10:01:47', '2016-11-26 10:01:47', ''),
(7, '', 'nanda@fma.com', '1222', '', '2016-11-26 13:47:40', '2016-11-26 13:47:40', '');
